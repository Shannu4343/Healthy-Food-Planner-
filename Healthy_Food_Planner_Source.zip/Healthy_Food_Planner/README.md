# Healthy Food Planner

A Flutter app for discovering simple healthy meals and planning them across the week.

## Features
- Browse sample healthy meals with meal type, preparation time, estimated calories, and protein.
- Search meals and filter by Breakfast, Lunch, Dinner, and Snacks.
- View full ingredients and cooking steps.
- Add custom meals with validation.
- Add meals to a seven-day meal plan and remove planned meals.
- Persist custom meals and the weekly plan locally with SharedPreferences.
- Provider state management, loading/error/retry/empty states.

## Screens
1. Meal Library – search and filter healthy meal ideas.
2. Meal Details – ingredients, cooking steps, and nutrition estimates.
3. Add Meal – validated form for a custom healthy meal.
4. Weekly Planner – view meals assigned to each day.

## Data source
The starter catalogue is local sample data in `lib/services/meal_data_service.dart`; it is not a medical or nutrition database. Calorie and protein values are rough illustrative estimates and can vary by ingredient, quantity, and preparation. Custom meals and weekly planning selections are saved locally with SharedPreferences. No external API key is required.

## Run
1. Install Flutter stable (3.35 or later recommended), Android Studio, and Android SDK.
2. Extract this project folder.
3. Open the folder in Android Studio or VS Code.
4. Run `flutter pub get`.
5. Connect an Android phone with USB debugging enabled, or start an emulator.
6. Run `flutter run`.

## Test
Run `flutter test`.

## Team contribution ideas
- Member 1: Meal Library, search, and filters.
- Member 2: Meal Details and Add Meal form.
- Member 3: Provider, local persistence, Weekly Planner, tests, and README.
Each member should make meaningful commits and understand their assigned feature.

## Important verification note
This is an initial source package. It has not been built or tested on a physical Android device in this environment. The team must run `flutter pub get`, `flutter analyze`, `flutter test`, and `flutter run`, then fix any issues before calling it submission-ready.
