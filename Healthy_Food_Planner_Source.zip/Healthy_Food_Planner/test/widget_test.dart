import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

import 'package:healthy_food_planner/models/meal.dart';\nimport 'package:healthy_food_planner/providers/meal_provider.dart';
import 'package:healthy_food_planner/screens/meal_library_screen.dart';
import 'package:healthy_food_planner/services/meal_storage_service.dart';

class FakeMealStorageService extends MealStorageService {
  @override
  Future<List<Meal>> loadCustomMeals() async => [];

  @override
  Future<Map<String, List<String>>> loadWeeklyPlan() async => {};
}

void main() {
  testWidgets('meal library displays sample healthy meals', (tester) async {
    final provider = MealProvider(FakeMealStorageService());
    await provider.load();

    await tester.pumpWidget(
      ChangeNotifierProvider.value(
        value: provider,
        child: const MaterialApp(home: MealLibraryScreen()),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Healthy Food Planner'), findsOneWidget);
    expect(find.text('Oats and Banana Bowl'), findsOneWidget);
  });
}
