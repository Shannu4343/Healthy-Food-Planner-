class Meal {
  const Meal({
    required this.id,
    required this.name,
    required this.mealType,
    required this.prepMinutes,
    required this.calories,
    required this.proteinGrams,
    required this.description,
    required this.ingredients,
    required this.steps,
    this.isCustom = false,
  });

  final String id;
  final String name;
  final String mealType;
  final int prepMinutes;
  final int calories;
  final int proteinGrams;
  final String description;
  final List<String> ingredients;
  final List<String> steps;
  final bool isCustom;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'mealType': mealType,
        'prepMinutes': prepMinutes,
        'calories': calories,
        'proteinGrams': proteinGrams,
        'description': description,
        'ingredients': ingredients,
        'steps': steps,
        'isCustom': isCustom,
      };

  factory Meal.fromJson(Map<String, dynamic> json) => Meal(
        id: json['id'] as String,
        name: json['name'] as String,
        mealType: json['mealType'] as String,
        prepMinutes: json['prepMinutes'] as int,
        calories: json['calories'] as int,
        proteinGrams: json['proteinGrams'] as int,
        description: json['description'] as String,
        ingredients: List<String>.from(json['ingredients'] as List),
        steps: List<String>.from(json['steps'] as List),
        isCustom: json['isCustom'] as bool? ?? false,
      );
}
