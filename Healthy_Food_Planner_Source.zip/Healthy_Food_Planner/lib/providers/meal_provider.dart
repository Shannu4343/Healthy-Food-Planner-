import 'package:flutter/foundation.dart';

import '../models/meal.dart';
import '../services/meal_data_service.dart';
import '../services/meal_storage_service.dart';

class MealProvider extends ChangeNotifier {
  MealProvider(this._storage);

  final MealStorageService _storage;
  final List<Meal> _customMeals = [];
  Map<String, List<String>> _weeklyPlan = {};
  bool isLoading = true;
  String? errorMessage;

  static const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  List<Meal> get meals => [...MealDataService.sampleMeals, ..._customMeals];
  Map<String, List<String>> get weeklyPlan => {
        for (final entry in _weeklyPlan.entries) entry.key: [...entry.value],
      };

  List<Meal> mealsForDay(String day) {
    final ids = _weeklyPlan[day] ?? [];
    return ids.map((id) => meals.where((meal) => meal.id == id).firstOrNull)
        .whereType<Meal>().toList();
  }

  Future<void> load() async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      _customMeals
        ..clear()
        ..addAll(await _storage.loadCustomMeals());
      _weeklyPlan = await _storage.loadWeeklyPlan();
    } catch (_) {
      errorMessage = 'Could not load saved meals. Please retry.';
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addMeal(Meal meal) async {
    _customMeals.insert(0, meal);
    notifyListeners();
    await _storage.saveCustomMeals(_customMeals);
  }

  Future<void> addToPlan(String day, String mealId) async {
    final ids = _weeklyPlan.putIfAbsent(day, () => []);
    if (!ids.contains(mealId)) ids.add(mealId);
    notifyListeners();
    await _storage.saveWeeklyPlan(_weeklyPlan);
  }

  Future<void> removeFromPlan(String day, String mealId) async {
    _weeklyPlan[day]?.remove(mealId);
    notifyListeners();
    await _storage.saveWeeklyPlan(_weeklyPlan);
  }

  Future<void> removeCustomMeal(String mealId) async {
    _customMeals.removeWhere((meal) => meal.id == mealId);
    for (final ids in _weeklyPlan.values) {
      ids.remove(mealId);
    }
    notifyListeners();
    await _storage.saveCustomMeals(_customMeals);
    await _storage.saveWeeklyPlan(_weeklyPlan);
  }
}
