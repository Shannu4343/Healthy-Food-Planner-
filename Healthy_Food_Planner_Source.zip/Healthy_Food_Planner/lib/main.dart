import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/meal_provider.dart';
import 'screens/meal_library_screen.dart';
import 'services/meal_storage_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => MealProvider(MealStorageService())..load(),
      child: const HealthyFoodPlannerApp(),
    ),
  );
}

class HealthyFoodPlannerApp extends StatelessWidget {
  const HealthyFoodPlannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Healthy Food Planner',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF287A4B),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7FAF5),
        appBarTheme: const AppBarTheme(centerTitle: false),
        cardTheme: CardTheme(
          elevation: 1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
      ),
      home: const MealLibraryScreen(),
    );
  }
}
