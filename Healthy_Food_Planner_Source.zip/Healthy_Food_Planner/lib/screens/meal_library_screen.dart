import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/meal.dart';
import '../providers/meal_provider.dart';
import '../widgets/meal_card.dart';
import 'add_meal_screen.dart';
import 'meal_detail_screen.dart';
import 'weekly_planner_screen.dart';

class MealLibraryScreen extends StatefulWidget {
  const MealLibraryScreen({super.key});

  @override
  State<MealLibraryScreen> createState() => _MealLibraryScreenState();
}

class _MealLibraryScreenState extends State<MealLibraryScreen> {
  final _searchController = TextEditingController();
  String _type = 'All';
  static const _types = ['All', 'Breakfast', 'Lunch', 'Dinner', 'Snacks'];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MealProvider>();
    final query = _searchController.text.trim().toLowerCase();
    final List<Meal> visible = provider.meals.where((meal) {
      final matchesText = meal.name.toLowerCase().contains(query) ||
          meal.mealType.toLowerCase().contains(query);
      return matchesText && (_type == 'All' || meal.mealType == _type);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Healthy Food Planner'),
        actions: [
          IconButton(
            tooltip: 'Weekly planner',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WeeklyPlannerScreen())),
            icon: const Icon(Icons.calendar_month),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddMealScreen())),
        icon: const Icon(Icons.add),
        label: const Text('Add meal'),
      ),
      body: RefreshIndicator(
        onRefresh: provider.load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
          children: [
            Text('Plan simple, balanced meals', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Explore meal ideas and organise your week.'),
            const SizedBox(height: 8),
            const Text('Nutrition values are approximate sample estimates.', style: TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 14),
            TextField(
              controller: _searchController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Search meals...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 42,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _types.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) => ChoiceChip(
                  label: Text(_types[index]),
                  selected: _type == _types[index],
                  onSelected: (_) => setState(() => _type = _types[index]),
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (provider.isLoading)
              const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()))
            else if (provider.errorMessage != null)
              Center(child: Column(children: [
                Text(provider.errorMessage!),
                TextButton(onPressed: provider.load, child: const Text('Retry')),
              ]))
            else if (visible.isEmpty)
              const Padding(padding: EdgeInsets.all(24), child: Text('No meals found. Try another filter or add a meal.', textAlign: TextAlign.center))
            else ...[
              Text('${visible.length} meal ideas', style: Theme.of(context).textTheme.titleSmall),
              const SizedBox(height: 8),
              ...visible.map((meal) => MealCard(
                    meal: meal,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MealDetailScreen(meal: meal))),
                  )),
            ],
          ],
        ),
      ),
    );
  }
}
