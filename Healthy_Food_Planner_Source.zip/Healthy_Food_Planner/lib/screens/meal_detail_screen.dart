import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/meal.dart';
import '../providers/meal_provider.dart';

class MealDetailScreen extends StatelessWidget {
  const MealDetailScreen({super.key, required this.meal});
  final Meal meal;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MealProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meal details'),
        actions: [
          if (meal.isCustom)
            IconButton(
              tooltip: 'Delete meal',
              onPressed: () async {
                await provider.removeCustomMeal(meal.id);
                if (context.mounted) Navigator.pop(context);
              },
              icon: const Icon(Icons.delete_outline),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            height: 145,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(colors: [Color(0xFFB7E4C7), Color(0xFF74C69D)]),
            ),
            child: const Icon(Icons.eco_outlined, size: 72, color: Color(0xFF1B4332)),
          ),
          const SizedBox(height: 18),
          Text(meal.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('${meal.mealType} • ${meal.prepMinutes} minutes'),
          const SizedBox(height: 12),
          Text(meal.description),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: _NutritionTile(label: 'Calories', value: '~${meal.calories} kcal')),
            const SizedBox(width: 10),
            Expanded(child: _NutritionTile(label: 'Protein', value: '~${meal.proteinGrams} g')),
          ]),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () => _showDayPicker(context, provider),
            icon: const Icon(Icons.calendar_month),
            label: const Text('Add to weekly plan'),
          ),
          const SizedBox(height: 22),
          Text('Ingredients', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          ...meal.ingredients.map((item) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.check_circle_outline, color: Colors.green),
                title: Text(item),
              )),
          const SizedBox(height: 16),
          Text('Preparation steps', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          ...meal.steps.asMap().entries.map((entry) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(radius: 14, child: Text('${entry.key + 1}', style: const TextStyle(fontSize: 12))),
                    const SizedBox(width: 10),
                    Expanded(child: Text(entry.value)),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Future<void> _showDayPicker(BuildContext context, MealProvider provider) async {
    final day = await showModalBottomSheet<String>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(title: Text('Choose a day')),
            ...MealProvider.days.map((day) => ListTile(
                  title: Text(day),
                  onTap: () => Navigator.pop(sheetContext, day),
                )),
          ],
        ),
      ),
    );
    if (day != null) {
      await provider.addToPlan(day, meal.id);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Added to $day')));
      }
    }
  }
}

class _NutritionTile extends StatelessWidget {
  const _NutritionTile({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(children: [
            Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            Text(label),
          ]),
        ),
      );
}
