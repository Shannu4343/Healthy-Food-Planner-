import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/meal_provider.dart';
import 'meal_detail_screen.dart';

class WeeklyPlannerScreen extends StatelessWidget {
  const WeeklyPlannerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MealProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Weekly meal planner')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Your plan for the week', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Add meals from a meal details page. You can assign a meal to more than one day.'),
          const SizedBox(height: 14),
          ...MealProvider.days.map((day) {
            final meals = provider.mealsForDay(day);
            return Card(
              child: ExpansionTile(
                initiallyExpanded: day == 'Monday',
                title: Text(day, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(meals.isEmpty ? 'No meals planned' : '${meals.length} planned meal(s)'),
                children: meals.isEmpty
                    ? [const Padding(padding: EdgeInsets.all(16), child: Text('Nothing planned for this day yet.'))]
                    : meals.map((meal) => ListTile(
                          title: Text(meal.name),
                          subtitle: Text('${meal.mealType} • ~${meal.calories} kcal'),
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MealDetailScreen(meal: meal))),
                          trailing: IconButton(
                            tooltip: 'Remove from plan',
                            icon: const Icon(Icons.remove_circle_outline),
                            onPressed: () => provider.removeFromPlan(day, meal.id),
                          ),
                        )).toList(),
              ),
            );
          }),
        ],
      ),
    );
  }
}
