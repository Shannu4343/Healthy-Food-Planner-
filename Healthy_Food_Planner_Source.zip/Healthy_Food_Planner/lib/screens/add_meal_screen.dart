import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/meal.dart';
import '../providers/meal_provider.dart';

class AddMealScreen extends StatefulWidget {
  const AddMealScreen({super.key});

  @override
  State<AddMealScreen> createState() => _AddMealScreenState();
}

class _AddMealScreenState extends State<AddMealScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _description = TextEditingController();
  final _minutes = TextEditingController(text: '20');
  final _calories = TextEditingController();
  final _protein = TextEditingController();
  final _ingredients = TextEditingController();
  final _steps = TextEditingController();
  String _type = 'Breakfast';
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    _minutes.dispose();
    _calories.dispose();
    _protein.dispose();
    _ingredients.dispose();
    _steps.dispose();
    super.dispose();
  }

  String? _required(String? value) =>
      value == null || value.trim().isEmpty ? 'This field is required' : null;

  String? _positiveInt(String? value) {
    final number = int.tryParse(value ?? '');
    if (number == null || number < 1 || number > 5000) return 'Enter a valid number';
    return null;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _saving) return;
    setState(() => _saving = true);
    final meal = Meal(
      id: 'custom_${DateTime.now().microsecondsSinceEpoch}',
      name: _name.text.trim(),
      mealType: _type,
      prepMinutes: int.parse(_minutes.text.trim()),
      calories: int.parse(_calories.text.trim()),
      proteinGrams: int.parse(_protein.text.trim()),
      description: _description.text.trim(),
      ingredients: _ingredients.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
      steps: _steps.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
      isCustom: true,
    );
    try {
      await context.read<MealProvider>().addMeal(meal);
      if (mounted) Navigator.pop(context);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add healthy meal')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Meal name'), validator: _required),
            const SizedBox(height: 12),
            TextFormField(controller: _description, decoration: const InputDecoration(labelText: 'Short description'), validator: _required, maxLines: 2),
            const SizedBox(height: 12),
            TextFormField(controller: _minutes, decoration: const InputDecoration(labelText: 'Preparation time (minutes)'), keyboardType: TextInputType.number, validator: _positiveInt),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _type,
              decoration: const InputDecoration(labelText: 'Meal type'),
              items: ['Breakfast', 'Lunch', 'Dinner', 'Snacks'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: (value) => setState(() => _type = value ?? 'Breakfast'),
            ),
            const SizedBox(height: 12),
            TextFormField(controller: _calories, decoration: const InputDecoration(labelText: 'Estimated calories (kcal)'), keyboardType: TextInputType.number, validator: _positiveInt),
            const SizedBox(height: 12),
            TextFormField(controller: _protein, decoration: const InputDecoration(labelText: 'Estimated protein (grams)'), keyboardType: TextInputType.number, validator: _positiveInt),
            const SizedBox(height: 12),
            TextFormField(controller: _ingredients, decoration: const InputDecoration(labelText: 'Ingredients (one per line)'), validator: _required, maxLines: 4),
            const SizedBox(height: 12),
            TextFormField(controller: _steps, decoration: const InputDecoration(labelText: 'Preparation steps (one per line)'), validator: _required, maxLines: 5),
            const SizedBox(height: 8),
            const Text('Nutrition figures are estimates entered by the user.', style: TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save),
              label: Text(_saving ? 'Saving...' : 'Save meal'),
            ),
          ],
        ),
      ),
    );
  }
}
