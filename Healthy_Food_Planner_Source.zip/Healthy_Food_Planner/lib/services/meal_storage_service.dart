import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/meal.dart';

class MealStorageService {
  static const _customMealsKey = 'custom_meals';
  static const _weeklyPlanKey = 'weekly_meal_plan';

  Future<List<Meal>> loadCustomMeals() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_customMealsKey);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
        .map((item) => Meal.fromJson(Map<String, dynamic>.from(item as Map)))
        .toList();
  }

  Future<void> saveCustomMeals(List<Meal> meals) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _customMealsKey,
      jsonEncode(meals.map((meal) => meal.toJson()).toList()),
    );
  }

  Future<Map<String, List<String>>> loadWeeklyPlan() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_weeklyPlanKey);
    if (raw == null || raw.isEmpty) return {};
    final decoded = Map<String, dynamic>.from(jsonDecode(raw) as Map);
    return decoded.map((day, ids) => MapEntry(day, List<String>.from(ids as List)));
  }

  Future<void> saveWeeklyPlan(Map<String, List<String>> plan) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_weeklyPlanKey, jsonEncode(plan));
  }
}
